import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { User } from './user.entity';
import { UsersDto } from './users.interface';
import { promises } from 'dns';

@Injectable()
export class UserService {
  constructor(
    @InjectRepository(User)
    private userRepository: Repository<User>,
  ) {}

  async AddUser(userDto: UsersDto): Promise<User> {
    const { name, edad } = userDto;
    
    let newUser = new User();
    newUser.name = name;
    newUser.edad = edad;

    const savedUser = await this.userRepository.save(newUser);
    return savedUser;
  }
  
  async editUser(id: number, userDto: UsersDto): Promise<User> {
    let toUpdate = await this.userRepository.findOneBy({id});
    
    if (!toUpdate) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }
  
    toUpdate.name = userDto.name;
    toUpdate.edad = userDto.edad;
  
    const updatedUser = await this.userRepository.save(toUpdate);
    return updatedUser;
  }
  
  
  

  getAll(): Promise<User[]> {
    return this.userRepository.find();
  }

  async getUserById(id: number): Promise<User> {
    const user = await this.userRepository.findOneBy({id});
    if (!user) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }
    return user;
  }

  async deleteUser(id: number): Promise<void> {
    const result = await this.userRepository.delete(id);
    if (result.affected === 0) {
      throw new NotFoundException(`User with ID ${id} not found`);
    }
  }
}
