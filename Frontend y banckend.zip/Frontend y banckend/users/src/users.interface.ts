export interface UsersDto{
    fecha_registro: Date;
    name: string;
    edad: number;
}