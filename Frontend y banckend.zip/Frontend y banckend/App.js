import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [users, setUsers] = useState([]);
  const [newUserName, setNewUserName] = useState('');
  const [newUserAge, setNewUserAge] = useState('');
  const [editingUserId, setEditingUserId] = useState(null);
  const [editingUserName, setEditingUserName] = useState('');
  const [editingUserAge, setEditingUserAge] = useState('');

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = () => {
    axios.get('http://localhost:3001/user')
      .then(response => {
        setUsers(response.data);
      })
      .catch(error => {
        console.error('Error fetching users:', error);
      });
  };

  const addUser = () => {
    axios.post('http://localhost:3001/user', {
      name: newUserName,
      edad: parseInt(newUserAge)
    })
    .then(response => {
      console.log('User added successfully:', response.data);
      fetchUsers();
      setNewUserName('');
      setNewUserAge('');
    })
    .catch(error => {
      console.error('Error adding user:', error);
    });
  };

  const deleteUser = (id) => {
    axios.delete(`http://localhost:3001/user/${id}`)
      .then(response => {
        console.log('User deleted successfully:', response.data);
        fetchUsers();
      })
      .catch(error => {
        console.error('Error deleting user:', error);
      });
  };

  const toggleEditUser = (id, name, edad) => {
    setEditingUserId(id);
    setEditingUserName(name);
    setEditingUserAge(edad);
  };

  const saveEditedUser = () => {
    axios.put(`http://localhost:3001/user/${editingUserId}`, {
      name: editingUserName,
      edad: parseInt(editingUserAge)
    })
    .then(response => {
      console.log('User updated successfully:', response.data);
      fetchUsers();
      setEditingUserId(null);
    })
    .catch(error => {
      console.error('Error updating user:', error);
    });
  };

  return (
    <div className="App">
      <header className="App-header">
        <h1>Lista de usuarios</h1>
        <div className="user-list">
          {users.map(user => (
            <div className="user-card" key={user.id}>
              {editingUserId === user.id ? (
                <div>
                  <input
                    type="text"
                    value={editingUserName}
                    onChange={e => setEditingUserName(e.target.value)}
                  />
                  <input
                    type="number"
                    value={editingUserAge}
                    onChange={e => setEditingUserAge(e.target.value)}
                  />
                  <button onClick={saveEditedUser}>Guardar</button>
                </div>
              ) : (
                <div>
                  <h2>{user.name}</h2>
                  <p>Edad: {user.edad}</p>
                  <button onClick={() => toggleEditUser(user.id, user.name, user.edad)}>Editar</button>
                  <button onClick={() => deleteUser(user.id)}>Eliminar</button>
                </div>
              )}
            </div>
          ))}
        </div>
        <div className="add-user-form-container">
  <h2>Agregar nuevo usuario:</h2>
  <input
    type="text"
    placeholder="Nombre"
    value={newUserName}
    onChange={e => setNewUserName(e.target.value)}
  />
  <input
    type="number"
    placeholder="Edad"
    value={newUserAge}
    onChange={e => setNewUserAge(e.target.value)}
  />
  <button onClick={addUser}>Agregar Usuario</button>
</div>

      </header>
    </div>
  );
}

export default App;
